## Setup
   1. install python
   The python you will need to install is python 2.7.15
   go to https://www.python.org/downloads/release/python-2715/ to choose the current version of your
   system to download the python 2.7.15 package you need to install
   - OSX: for OSX, one you download and install the package, you are all set
   - Windows: for windows, after you have install the package, you still need to configure python to
   make it work in command line. (A detailed guide on how to do that on windows: https://www.youtube.com/watch?v=gD4eulxGNok)

## Run the program
   Download and unzip the folder and use command tool to navigate to the folder
   Once you are inside the folder, type 'python main.py'
   That will run the program

## Structure
    - input: the input files folder
    - output: the output files folder
    - main.py:
        main() : read all files from the input folder, parse the files and write to csv files
    - record.py:
        A Record class model to hold all the data
    - settings.py:
        centralized configured settings for easy changes
    - utils.py:
        all the utils functions
        data_parser() : a helper function to reduce the duplicate code to extract the first value of some code_name and tag_name
        parse_file() : the function to parse xml files and construct a record instance of those data
        write_to_csv() : a function to output the datas to a csv file

## Some possible later improvements for this program
   You can also add validate for the data you want to harvest from the xml files,
   ex: check if url field gives your a correct url, check if id meets certain format
   And it can be stored in a DB as a record object and then later on if it is needed
   retrieve those data from DB to do analysis or output to a csv file


