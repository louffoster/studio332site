class Record:
    """
        A record class that can hold the information parse from xml file,
        the reason for this is you can add more function to this class to
        analysis data, do data validation and store them into database if
        it is necessary
    """
    def __init__(self, file_name, title_statment, call_number, url=''):
        self.file_name = file_name
        self.title_statment = title_statment
        self.call_number = call_number
        self.url = url
