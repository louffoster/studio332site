import os

# input default settings from settings.py so they are configured and can be changed easily
from settings import INPUT_FOLDER, OUTPUT_FOLDER, OUTPUT_FILENAME, FILELDS_NAME
# import the util funciton
from utils import parse_file, write_to_csv


def main():
    # collect all file's file name from the input folder
    files_list = [f for f in os.listdir(INPUT_FOLDER) if os.path.isfile(os.path.join(INPUT_FOLDER, f))]

    # parse all the files and contruct as dict to write to csv
    data_list = []
    for file in files_list:
        input_file_path = '{}/{}'.format(INPUT_FOLDER, file)
        record = parse_file(input_file_path)
        data_list.append(
            {
                'id': record.file_name,
                'title statement': record.title_statment,
                'call number': record.call_number,
                'url': record.url
            }
        )

    # write to csv file
    output_file_path = '{}/{}'.format(OUTPUT_FOLDER, OUTPUT_FILENAME)
    write_to_csv(output_file_path, data_list, FILELDS_NAME)
    # indicate the program has finished running
    print('Parse files and write to csv done.')

if __name__ == '__main__':
    main()