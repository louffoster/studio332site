#configured settings
INPUT_FOLDER = 'input'
OUTPUT_FOLDER = 'output'
OUTPUT_FILENAME = 'desired-output.csv'
FILELDS_NAME= ['id', 'title statement', 'call number', 'url']