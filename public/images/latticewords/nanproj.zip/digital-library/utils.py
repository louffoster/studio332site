import os
import csv
import xml.etree.ElementTree as ET

# input the record class
from record import Record


# helper function to extract the first value of a given tag_number and code_number
def data_parser(elements_list, first_detected, tag_number, code_number):
    return_value = ''
    if elements_list.attrib['tag'] == tag_number:
        for element in elements_list:
            if element.attrib['code'] == code_number and 'subfield' in element.tag:
                return_value = element.text
                first_detected = False
                break
    return return_value, first_detected


def parse_file(input_file_path):
    """
        parse the xml file and return the created Record holding data from each of the file
    :param String input_file_path: the path and filename of the xml file to be parsed
    :return Record record:  a Record object with the information from the xml file
    """
    tree = ET.parse(input_file_path)
    root = tree.getroot()

    # parse the input file_path to get the current file name without .xml extension
    file_name = input_file_path.split('/')[-1].strip('.xml')

    title_statment = ''
    call_number = ''
    url = ''
    first_call_number = True
    first_url = True

    # find all datafield of the file and then do the data collection
    for child in root.findall(root.tag.strip('record') + 'datafield'):
        # add up all the value of any subfield of tag 245 of datafield for the title_statement
        if child.attrib['tag'] == '245':
            for x in child:
                title_statment += ' ' + x.text

        # collect the first value of all the datafield wih tag 999 for call number
        if first_call_number:
            call_number, first_call_number = data_parser(child, first_call_number, '999', 'a')

        # collect the first value of all the datafield wih tag 856 for url
        if first_url:
            url, first_url = data_parser(child, first_url, '856', 'u')

    return Record(file_name=file_name, title_statment=title_statment, call_number=call_number, url=url)


# helper_function to write to csv file
def write_to_csv(output_file_path, data_list, fieldnames):
    # remove the file if it is already there
    try:
        os.remove(output_file_path)
    except OSError:
        pass

    # write to the csv file
    with open(output_file_path, 'wb') as myfile:
        writer = csv.DictWriter(myfile, fieldnames=fieldnames)
        writer.writeheader()
        for x in data_list:
            writer.writerow(x)

